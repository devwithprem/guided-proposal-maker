// Tailwind CSS v4 Plugin for @devcode-tech/form-builder
// This plugin adds custom utilities and components for the form builder

import plugin from 'tailwindcss/plugin';

export default plugin(function({ addBase, addUtilities, addComponents, theme }) {
  // Add keyframes for animations
  addBase({
    '@keyframes fadeIn': {
      '0%': { opacity: '0', transform: 'translateY(-10px)' },
      '100%': { opacity: '1', transform: 'translateY(0)' },
    },
    '@keyframes slideIn': {
      '0%': { transform: 'translateX(-100%)' },
      '100%': { transform: 'translateX(0)' },
    },
    '@keyframes pulse': {
      '0%, 100%': { opacity: '1' },
      '50%': { opacity: '0.5' },
    },
  });

  // Add form builder utilities
  addUtilities({
    '.animate-fade-in': {
      animation: 'fadeIn 0.3s ease-out',
    },
    '.animate-slide-in': {
      animation: 'slideIn 0.3s ease-out',
    },
    '.animate-pulse-custom': {
      animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
    },
    '.form-builder-container': {
      minHeight: '100vh',
      backgroundColor: '#f9fafb',
    },
    '.form-builder-field': {
      transition: 'all 0.2s ease-in-out',
    },
    '.form-builder-dragging': {
      opacity: '0.5',
      cursor: 'grabbing',
    },
    '.form-builder-drop-zone': {
      border: '2px dashed rgb(96 165 250)',
      backgroundColor: 'rgb(239 246 255)',
      borderRadius: '0.5rem',
      padding: '1rem',
      transition: 'all 0.2s ease-in-out',
    },
    '.form-builder-drop-zone-active': {
      borderColor: 'rgb(59 130 246)',
      backgroundColor: 'rgb(219 234 254)',
    },
  });

  // Add form components
  addComponents({
    '.form-preview': {
      backgroundColor: 'white',
      borderRadius: '0.5rem',
      boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
      padding: '2rem',
      maxWidth: '56rem',
      margin: '0 auto',
    },
    '.form-field-container': {
      marginBottom: '1.5rem',
      '&:last-child': {
        marginBottom: '0',
      },
    },
    '.form-label': {
      display: 'block',
      fontSize: '0.875rem',
      fontWeight: '500',
      color: 'rgb(55 65 81)',
      marginBottom: '0.5rem',
      '&.required::after': {
        content: '" *"',
        color: 'rgb(239 68 68)',
      },
    },
    '.form-input': {
      width: '100%',
      padding: '0.5rem 0.75rem',
      border: '1px solid rgb(209 213 219)',
      borderRadius: '0.375rem',
      fontSize: '1rem',
      transition: 'all 0.15s ease-in-out',
      '&:focus': {
        outline: 'none',
        boxShadow: '0 0 0 3px rgba(59, 130, 246, 0.1)',
        borderColor: 'rgb(59 130 246)',
      },
      '&:disabled': {
        backgroundColor: 'rgb(243 244 246)',
        cursor: 'not-allowed',
        opacity: '0.6',
      },
      '&.error': {
        borderColor: 'rgb(239 68 68)',
        '&:focus': {
          boxShadow: '0 0 0 3px rgba(239, 68, 68, 0.1)',
        },
      },
    },
    '.form-error': {
      fontSize: '0.875rem',
      color: 'rgb(220 38 38)',
      marginTop: '0.25rem',
      display: 'flex',
      alignItems: 'center',
      gap: '0.25rem',
    },
    '.form-button': {
      padding: '0.5rem 1rem',
      borderRadius: '0.375rem',
      fontWeight: '500',
      transition: 'all 0.15s ease-in-out',
      cursor: 'pointer',
      border: 'none',
      '&:disabled': {
        opacity: '0.5',
        cursor: 'not-allowed',
      },
      '&.primary': {
        backgroundColor: 'rgb(59 130 246)',
        color: 'white',
        '&:hover:not(:disabled)': {
          backgroundColor: 'rgb(37 99 235)',
        },
      },
      '&.secondary': {
        backgroundColor: 'rgb(243 244 246)',
        color: 'rgb(55 65 81)',
        '&:hover:not(:disabled)': {
          backgroundColor: 'rgb(229 231 235)',
        },
      },
    },
    '.file-upload-zone': {
      border: '2px dashed rgb(209 213 219)',
      borderRadius: '0.5rem',
      padding: '2rem',
      textAlign: 'center',
      cursor: 'pointer',
      transition: 'all 0.2s ease-in-out',
      '&:hover': {
        borderColor: 'rgb(59 130 246)',
        backgroundColor: 'rgb(249 250 251)',
      },
      '&.dragging': {
        borderColor: 'rgb(59 130 246)',
        backgroundColor: 'rgb(239 246 255)',
      },
    },
  });
});
