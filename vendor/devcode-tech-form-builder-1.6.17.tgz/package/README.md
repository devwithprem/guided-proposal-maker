# @devcode-tech/form-builder

A powerful drag-and-drop form builder for Next.js applications with Supabase integration.

## Features

- 🎨 **20+ Field Types** - Text, email, phone, date, file uploads, rich text, and more
- 🎯 **Drag & Drop** - Intuitive builder interface
- ✅ **Built-in Validation** - Comprehensive validation rules
- 🔀 **Conditional Logic** - Show/hide fields based on conditions
- 🌈 **Customizable Design** - Full control over styling
- 🔌 **Callback-Based** - Full control over form persistence with your own backend
- 💾 **Database Agnostic** - Works with Supabase, Prisma, Firebase, or any backend
- 📱 **Responsive** - Works on all devices

## Installation

### Install from GitHub

```bash
npm install git+https://github.com/yourusername/form-builder.git
```

### Or clone locally

```bash
git clone https://github.com/yourusername/form-builder.git
```

## Usage

> 📖 **Quick Start**: Check out [USAGE_EXAMPLES.md](./USAGE_EXAMPLES.md) for complete examples with React, Next.js, and API integration.

> 🌐 **New in v1.2.7**: Full internationalization support with English and Arabic translations, including RTL support.

> 📖 **Parent App Integration**: See [LANGUAGE_INTEGRATION.md](./LANGUAGE_INTEGRATION.md) for detailed guide on integrating with your app's language system.

## Internationalization (i18n)

The form builder includes built-in support for multiple languages with English and Arabic translations out of the box.

### Using with Parent App Language (Recommended)

If your parent application already has language selection, simply pass the selected language to the form builder:

```tsx
import { FormBuilder } from '@devcode-tech/form-builder';
import '@devcode-tech/form-builder/styles.css';

export default function MyFormBuilder() {
  const { language } = useYourAppLanguageContext(); // Get from your app
  
  return (
    <FormBuilder
      locale={language} // 'en' or 'ar'
      schema={formSchema}
      onSchemaChange={handleSchemaChange}
    />
  );
}
```

**Key Benefits:**
- ✅ Automatically syncs with your app's language
- ✅ No need to manage separate language state
- ✅ RTL support handled automatically for Arabic

For complete integration examples with Next.js i18n, React Context, and more, see [LANGUAGE_INTEGRATION.md](./LANGUAGE_INTEGRATION.md).

### Setup with LocaleProvider

Wrap your form builder with the `LocaleProvider` to enable translations:

```tsx
import { EditableFormBuilder, LocaleProvider } from '@devcode-tech/form-builder';

export default function FormBuilderPage() {
  return (
    <LocaleProvider>
      <div className="h-screen">
        <EditableFormBuilder />
      </div>
    </LocaleProvider>
  );
}
```

### Language Switching

Use the `useLocale` hook to switch languages:

```tsx
import { LocaleProvider, useLocale } from '@devcode-tech/form-builder';

function LanguageSwitcher() {
  const { locale, setLocale } = useLocale();
  
  return (
    <button onClick={() => setLocale(locale === 'en' ? 'ar' : 'en')}>
      Switch to {locale === 'en' ? 'Arabic' : 'English'}
    </button>
  );
}

export default function App() {
  return (
    <LocaleProvider>
      <LanguageSwitcher />
      <EditableFormBuilder />
    </LocaleProvider>
  );
}
```

### Supported Languages

- **English (en)** - Default language
- **Arabic (ar)** - Full RTL support

### Custom Translations

You can use the translation hooks in your own components:

```tsx
import { useTranslation, useFormBuilderTranslations } from '@devcode-tech/form-builder';

function MyComponent() {
  const { t } = useTranslation('common');
  const { t: tBuilder } = useFormBuilderTranslations();
  
  return (
    <div>
      <button>{t('save')}</button>
      <h1>{tBuilder('title')}</h1>
    </div>
  );
}
```

### Available Translation Hooks

- `useTranslation(namespace)` - General translation hook
- `useCommonTranslations()` - Common UI strings (save, cancel, etc.)
- `useFormBuilderTranslations()` - Form builder specific strings
- `useValidationTranslations()` - Validation messages
- `useFieldTypeTranslations()` - Field type labels

### Basic Form Builder

```tsx
import { EditableFormBuilder } from '@flint/form-builder';

export default function FormBuilderPage() {
  return (
    <div className="h-screen">
      <EditableFormBuilder />
    </div>
  );
}
```

### Display a Form (Preview Component)

The `FormPreviewLive` component can be used **standalone** anywhere in your app to display forms. This is perfect for showing forms on different pages, embedding forms, or creating form viewers.

```tsx
import { FormPreviewLive } from '@flint/form-builder';
import type { FormFieldData, FormDesign, LayoutContainer } from '@flint/form-builder';

export default function DisplayFormPage() {
  const fields: FormFieldData[] = [
    {
      id: 'field_1',
      type: 'text',
      name: 'email',
      label: 'Email Address',
      placeholder: 'Enter your email',
      required: true,
      width: 'w-full',
    },
  ];

  const containers: LayoutContainer[] = [
    {
      id: 'container_1',
      type: 'single-column',
      fields: [],
      leftFields: ['field_1'],
      rightFields: [],
    },
  ];

  const design: FormDesign = {
    backgroundColor: '#ffffff',
    fontFamily: 'font-sans',
    fontSize: 'text-base',
    spacing: {
      container: 'p-8',
      fields: 'space-y-6',
      columnGap: '1.5rem',
      rowGap: '1.5rem',
    },
    submitButton: {
      text: 'Submit',
      backgroundColor: '#2563eb',
      textColor: '#ffffff',
    },
  };

  return (
    <FormPreviewLive
      fields={fields}
      containers={containers}
      formTitle="Contact Form"
      formDescription="Fill out this form"
      formDesign={design}
    />
  );
}
```

**Key Features:**
- ✅ Fully responsive on all devices
- ✅ Theme customization (spacing, fonts, colors)
- ✅ Supports all 20+ field types
- ✅ Built-in validation
- ✅ Can be used independently from the builder

### With Supabase (Optional)

If you want to store forms in Supabase, the form builder works seamlessly with your existing Supabase setup. Just pass your Supabase client context to your app.

```tsx
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
import { EditableFormBuilder } from '@flint/form-builder';

export default function FormBuilderPage() {
  const supabase = createClientComponentClient();
  
  // The form builder will automatically use your Supabase client
  // if it's available in your app's context
  
  return <EditableFormBuilder />;
}
```

## Available Components

- `EditableFormBuilder` - Main form builder interface with callback support
- `FormPreviewLive` - Display forms to end users
- `FieldDesignInspector` - Field configuration panel
- `ThemeInspector` - Form theme customization
- `LocaleProvider` - i18n provider for multi-language support
- `useLocale` - Hook for language switching
- `useTranslation` - Translation hooks for custom components

## Callback System

The form builder uses a callback-based architecture for maximum flexibility. When users click the **Save** or **Update** buttons, your callbacks are triggered with the complete form data.

### Quick Start

```tsx
import { FormBuilder } from '@devcode-tech/form-builder';
import '@devcode-tech/form-builder/styles.css';

export default function MyFormBuilder() {
  const handleSave = async (data) => {
    // Save to your backend
    const response = await fetch('/api/forms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data.schema), // Save the schema
    });
    const result = await response.json();
    return result.formId; // Return the created form ID
  };

  const handleUpdate = async (formId, data) => {
    // Update existing form
    const response = await fetch(`/api/forms/${formId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data.schema),
    });
    return response.ok; // Return true on success
  };

  const handleLoad = async (formId) => {
    // Load form data
    const response = await fetch(`/api/forms/${formId}`);
    return await response.json();
  };

  return (
    <FormBuilder
      initialFormId={formId}
      onSave={handleSave}
      onUpdate={handleUpdate}
      onLoad={handleLoad}
      locale="en"
    />
  );
}
```

### Available Callbacks

- **`onSave(data)`** - Called when Save button is clicked (Create mode)
  - Receives: Complete form data including `schema`, `fields`, `containers`, `design`
  - Returns: Created form ID (string) on success, null on failure

- **`onUpdate(formId, data)`** - Called when Update button is clicked (Edit mode)
  - Receives: Form ID and complete form data
  - Returns: true on success, false on failure

- **`onLoad(formId)`** - Called when loading a form in edit mode
  - Receives: Form ID to load
  - Returns: Form data (will be normalized automatically)

- **`onSubmit(formData)`** - Called when a form is submitted in preview mode
  - Receives: Key-value pairs of field names and values
  - Returns: Promise<void>

### 📖 Detailed Documentation

For complete examples with React, Next.js, API routes, and data structure reference, see:
- **[USAGE_EXAMPLES.md](./USAGE_EXAMPLES.md)** - Comprehensive usage guide with real-world examples
- **[CALLBACK_GUIDE.md](./CALLBACK_GUIDE.md)** - Advanced callback patterns and best practices

### What Data Do You Receive?

The `data` object passed to `onSave` and `onUpdate` contains:

```typescript
{
  title: string,              // Form title
  description: string,        // Form description
  fields: FormFieldData[],    // Array of fields with styling
  containers: LayoutContainer[], // Layout containers
  design: FormDesign,         // Design configuration
  schema: {                   // ⭐ SDK-friendly schema (recommended to save)
    id: string,
    name: string,
    title: string,
    description: string,
    fields: [...],            // Fields with CSS properties
    containers: [...],
    design: {...}
  }
}
```

**💡 Tip**: Save `data.schema` - it's optimized for rendering and includes all necessary styling.

## Available Types

```tsx
import type {
  FormFieldData,
  FieldStyle,
  ValidationRule,
  FormDesign,
  ConditionalLogic,
} from '@flint/form-builder';
```

## Field Types Supported

- Text, Email, Phone, Postal Code
- Number, Date, Time
- Long Text, Rich Text
- Dropdown, Radio, Checkbox
- File, Image, Video, Document
- Terms & Conditions
- Separator

## Styling

The form builder uses **Tailwind CSS v4.1+**. Make sure your project has Tailwind v4 configured with PostCSS.

**Important:** This package uses Tailwind v4, which does NOT work with Sass/SCSS preprocessors. See [Tailwind v4 Compatibility Guide](./TAILWIND_V4_COMPATIBILITY.md) for details.

### Quick Setup

1. Install Tailwind v4:
```bash
npm install --save-dev tailwindcss@^4.1.0 @tailwindcss/postcss@^4.1.0
```

2. Configure PostCSS:
```javascript
// postcss.config.mjs
export default {
  plugins: {
    "@tailwindcss/postcss": {},
  },
};
```

3. Import styles:
```tsx
import '@devcode-tech/form-builder/styles.css';
```

For detailed setup instructions for your specific framework, see [Consumer Setup Guide](./CONSUMER_SETUP_GUIDE.md).

## Requirements

- React 18+ or 19+
- Next.js 14+ or 15+ (or any framework with PostCSS support)
- Tailwind CSS v4.1+
- PostCSS 8+
- Supabase JS 2+ (optional, only if using database features)

## License

MIT

## Support

For issues or questions, please open an issue on GitHub.
